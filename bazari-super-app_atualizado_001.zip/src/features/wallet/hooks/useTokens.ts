// src/features/wallet/hooks/useTokens.ts
import React from 'react'
import type { ApiPromise } from '@polkadot/api'
import { BN } from '@polkadot/util'
import { useActiveAccount } from './useActiveAccount'

// ===== Tipos esperados pelo TokensTab / WalletHome =====
export type TokenWithBalance = {
  key: string
  symbol: string
  name?: string
  type?: 'native' | 'asset'
  formattedBalance: string
  balanceInFiat?: number
  priceUSD?: number
}

// ==== Integração com a Bazarichain ====
// Se você já tem um provider de chain, exponha o api aqui.
// O seu projeto lista `ChainProvider` nos providers. Normalmente existe um hook:
//
//   import { useChain } from '@app/providers/ChainProvider'
//
// que retorna { api, isReady } ou similar. Ajuste o import abaixo conforme seu projeto.

type ChainCtx = {
  api?: ApiPromise | null
  isReady?: boolean
}

function useChainLike(): ChainCtx {
  // 🔁 Troque este import pelo hook real do seu provider, por exemplo:
  // const { api, isReady } = useChain()
  // return { api, isReady }
  //
  // Para evitar quebrar durante a integração, exponho uma “ponte” que você só precisa
  // implementar no ChainProvider (ou substitua esta função pelo seu hook real).
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require('@app/providers/ChainProvider')
    if (mod && typeof mod.useChain === 'function') {
      const { api, isReady } = mod.useChain()
      return { api, isReady }
    }
  } catch {
    // noop (sem provider, segue com api undefined)
  }
  return { api: undefined, isReady: false }
}

// ===== Helpers =====
function formatFromBase(amount: BN | bigint, decimals: number): string {
  const base = amount instanceof BN ? amount : new BN(amount.toString())
  const d = new BN(10).pow(new BN(decimals))
  const int = base.div(d).toString()
  const fracBN = base.mod(d)
  if (fracBN.isZero()) return int
  const fracStr = fracBN.toString().padStart(decimals, '0').replace(/0+$/, '')
  return fracStr.length ? `${int}.${fracStr}` : int
}

// ===== Mock/Registry de assets (opcional) =====
// Deixe uma única fonte para listar quais assets você deseja exibir.
// Integre com seu registry local, API, ou arquivo de config.
// Se não tiver assets, deixe vazio e só o nativo será mostrado.
type AssetMeta = { id: string | number; symbol: string; name?: string; decimals: number; priceUSD?: number }

// ⚠️ PLUGUE AQUI SEUS ASSETS:
//   - substitua por leitura do seu registry/arquivo de config
//   - ou por uma chamada à API do seu backend
async function listTrackedAssets(): Promise<AssetMeta[]> {
  return [
    // Exemplo:
    // { id: 1, symbol: 'USDB', name: 'USD Bazari', decimals: 6, priceUSD: 1 },
    // { id: 2, symbol: 'GOLD', name: 'Gold Token', decimals: 8, priceUSD: 75 },
  ]
}

// Consulta saldo do pallet-assets (quando existir)
async function fetchAssetBalance(api: ApiPromise, address: string, asset: AssetMeta): Promise<BN> {
  // Suporte a pallet-assets padrão: assets.account(assetId, accountId) => { balance, ... }
  try {
    // Alguns nodes usam u32/u128 para o id — converta para o tipo aceito:
    const id = typeof asset.id === 'string' ? asset.id : Number(asset.id)
    // @ts-ignore – sobrecargas do polkadot.js variam por runtime
    const acc = await api.query.assets.account(id, address)
    const bal = (acc as any)?.balance
    if (bal) return new BN(bal.toString())
  } catch {
    // pallet não disponível ou erro – devolve zero
  }
  return new BN(0)
}

// ===== O Hook principal =====
export function useTokens() {
  const { activeAccount } = useActiveAccount() // ✅ mesma fonte do Auth
  const { api, isReady } = useChainLike()

  const [isLoading, setIsLoading] = React.useState(false)
  const [nativeToken, setNativeToken] = React.useState<TokenWithBalance | undefined>(undefined)
  const [assetTokens, setAssetTokens] = React.useState<TokenWithBalance[]>([])
  const [error, setError] = React.useState<string | null>(null)

  const address = activeAccount?.address

  const load = React.useCallback(async () => {
    if (!api || !isReady || !address) {
      setNativeToken(undefined)
      setAssetTokens([])
      return
    }

    setIsLoading(true)
    setError(null)
    try {
      // ===== 1) Metadados da chain (símbolo/decimais do token nativo) =====
      const [decimalsArr, tokensArr] = [api.registry.chainDecimals(), api.registry.chainTokens()]
      const chainDecimals = (decimalsArr && decimalsArr[0]) ?? 12
      const chainSymbol = (tokensArr && tokensArr[0]) ?? 'BZR'

      // ===== 2) Saldo nativo pelo system.account =====
      // structure: { data: { free, reserved, miscFrozen, feeFrozen } }
      const sysAcc = await api.query.system.account(address)
      const free = (sysAcc as any)?.data?.free
      const freeBN = new BN(free?.toString() ?? '0')
      const formattedNative = formatFromBase(freeBN, chainDecimals)

      const native: TokenWithBalance = {
        key: 'native',            // chave estável para o token nativo
        symbol: chainSymbol,
        name: chainSymbol,
        type: 'native',
        formattedBalance: formattedNative,
        // Se você tiver um oráculo de preço, preencha abaixo:
        // priceUSD: <número>,
        // balanceInFiat: priceUSD ? parseFloat(formattedNative) * priceUSD : undefined,
      }
      setNativeToken(native)

      // ===== 3) Assets (opcional) via pallet-assets =====
      const metas = await listTrackedAssets()
      const assets: TokenWithBalance[] = []

      for (const m of metas) {
        const balBN = await fetchAssetBalance(api, address, m)
        const formatted = formatFromBase(balBN, m.decimals)
        const price = m.priceUSD
        const fiat = price != null ? parseFloat(formatted || '0') * price : undefined

        assets.push({
          key: String(m.id),
          symbol: m.symbol,
          name: m.name ?? m.symbol,
          type: 'asset',
          formattedBalance: formatted,
          priceUSD: price,
          balanceInFiat: fiat,
        })
      }

      setAssetTokens(assets)
    } catch (e: any) {
      setError(e?.message || 'Falha ao carregar saldos')
      setNativeToken(undefined)
      setAssetTokens([])
    } finally {
      setIsLoading(false)
    }
  }, [api, isReady, address])

  // Recarrega sempre que a conta ativa ou a conexão mudarem
  React.useEffect(() => {
    void load()
  }, [load])

  const refreshBalances = React.useCallback(async () => {
    await load()
  }, [load])

  const tokens: TokenWithBalance[] = React.useMemo(() => {
    const list: TokenWithBalance[] = []
    if (nativeToken) list.push(nativeToken)
    if (assetTokens?.length) list.push(...assetTokens)
    return list
  }, [nativeToken, assetTokens])

  // totalBalance: soma em FIAT se disponível; senão, usa o nativo como fallback
  const totalBalance = React.useMemo(() => {
    const fiatSum = tokens.reduce((acc, t) => acc + (t.balanceInFiat || 0), 0)
    if (fiatSum > 0) return fiatSum
    const nat = nativeToken ? parseFloat(nativeToken.formattedBalance) : 0
    return nat
  }, [tokens, nativeToken])

  return {
    tokens,
    nativeToken,
    assetTokens,
    totalBalance,
    isLoading,
    error,
    refreshBalances,
  }
}
