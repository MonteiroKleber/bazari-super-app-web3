// src/features/marketplace/services/index.ts

// Export P2P service
export { p2pService } from './p2pService'

// Future marketplace services can be added here
// export { marketplaceService } from './marketplaceService'
// export { enterpriseService } from './enterpriseService'
// export { paymentService } from './paymentService'